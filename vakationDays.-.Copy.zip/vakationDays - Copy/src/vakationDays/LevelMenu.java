package vakationDays;

import org.newdawn.slick.*;
import org.newdawn.slick.state.*;

public class LevelMenu extends BasicGameState {
 public LevelMenu (int state){
	 
 }
  public void init(GameContainer gc, StateBasedGame sbg) throws SlickException{	  
  }
  public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException{
	  }

  public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException{
	  }
 
  public int getID(){
	  return 101;
  }

}
