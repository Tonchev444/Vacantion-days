package vakationDays;

import org.newdawn.slick.*;
import org.newdawn.slick.state.*;

public class Level1 extends BasicGameState {
 public Level1 (int state){
	 
 }
  public void init(GameContainer gc, StateBasedGame sbg) throws SlickException{	  
  }
  public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException{
	  g.drawString("hey you actually made it", 50, 50);
	  
	  }

  public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException{
	  }
 
  public int getID(){
	  return 1;
  }

}
