package vakationDays;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;

public class Menu extends BasicGameState {
	
	
 public Menu (int state){ 
 }
  public void init(GameContainer gc, StateBasedGame sbg) throws SlickException{	    
  }
  
  public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException{
	  g.drawRoundRect(250, 230, 140, 50, 20);
	  g.drawString("Play", 300, 245);
	  g.drawRoundRect(250, 285, 140, 50, 20);
	  g.drawString("EXIT GAME", 280, 300);
	  }

  public void update(GameContainer gc, StateBasedGame sbg, int delta) throws SlickException{
	  Input input = gc.getInput();
	  int xpos = Mouse.getX();
	  int ypos = Mouse.getY();
	  if((xpos>250&&xpos<350)&&(ypos>80&&ypos<130)){
		  if(input.isMouseButtonDown(0)){
			  sbg.enterState(1);
		  }
	  }
	  if((xpos>250&&xpos<350)&&(ypos>25&&ypos<75)){
		  if(input.isMouseButtonDown(0)){
			  System.exit(0);
		  }
			  
		  }
	  }
 
  public int getID(){
	  return 0;
  }

}
